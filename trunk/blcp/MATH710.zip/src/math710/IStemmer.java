/*
 * IStemmer.java
 *
 * Created on February 13, 2006, 3:33 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package math710;

/**
 *
 * @author mike
 */
public interface IStemmer {
    String stem(String t);
}
